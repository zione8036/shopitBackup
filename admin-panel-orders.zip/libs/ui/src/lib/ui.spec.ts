import { ui } from './ui';

describe('ui', () => {
  it('should work', () => {
    expect(ui()).toEqual('ui');
  });
});
