export function ui(): string {
  return 'ui';
}
